declare const useUserState: import("zustand").UseBoundStore<import("zustand").StoreApi<unknown>>;
export { useUserState };
